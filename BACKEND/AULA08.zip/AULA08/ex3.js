for(let i = 10 ; i >=0 ; i-= 1) {
    console.log(`Contagem regressiva... ${i}`);
}
console.log("O foguete decolou!");