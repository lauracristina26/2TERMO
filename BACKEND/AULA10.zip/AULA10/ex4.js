const entrada = require("readline-sync");

console.log("=== REGISTRO DE TEMPERATURAS===");

const temperaturas = [];

const quantidade = entrada.questionInt("Quantas temperaturas deseja registrar? ");

for(let i= 0; i < quantidade; i++ ) {
    let temperatura = entrada.questionFloat(`Temperatura ${i +1}: `);
    temperaturas.push(temperatura);
}
console.log("\n--- RELATÓRIO---");
console.log(`Temperaturas registradas: ${temperaturas.join("°C | ")} °C`);
console.log(`Quantidade de registro: ${temperaturas.length}`);
console.log(`Primeira Temperatura: ${temperaturas[0]}`);
console.log(`Última Temperatura: ${temperaturas[temperaturas.length - 1]}`); // Para achar o indice do ultimo numero do array


// 1. Mostrar a quantidade de registro
// 2. Mostrar a primeira temperatura
// 3. Mostrar a última temperatura