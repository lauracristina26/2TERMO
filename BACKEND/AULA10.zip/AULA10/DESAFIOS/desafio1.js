const entrada = require("readline-sync")

console.log("=== SISTEMA DE CONTROLE DE QUALIDADE ===");

const pesos = [];

const somaTotal = entrada.questionFloat(`Quantas pecas voce quer armazenar?: `)

for(let i= 0; i < somaTotal; i++) {
    let peso = entrada.questionFloat(`Pecas ${i+1}: `);
    pesos.push(peso);
}

console.log("\n=== RELATÓRIO ===");
console.log(`Pesos registrados: ${pesos.join(" kg | ")} kg`)

const media = (${i=1} / pesos.length)