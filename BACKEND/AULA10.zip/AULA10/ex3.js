const alunos = ["Ana", "Bruno", "Carlos", "Enzo", "Isabelli", "Daniel"];

console.log("Lista De Alunos:");
console.log(alunos); 


console.log(`Primeiro aluno: ${alunos[0]}`);
console.log(`Segundo aluno: ${alunos[1]}`);
console.log(`Terceiro aluno: ${alunos[4]}`);
console.log(`Último aluno: ${alunos[5]}`);


alunos.push("Cecília");
alunos.push("Leona");
alunos.splice(3,1);

console.log(alunos); 
console.log(`Segundo aluno: ${alunos[2]}`);
console.log(`Último aluno: ${alunos[alunos.length - 1]}`);
console.log(`Quantidade de alunos: ${alunos.length}`); //length conta a quantidade de alunos 

//acresentar mais 2 nomes ao array
//mostrar o terceiro aluno
//mostrar o último aluno

