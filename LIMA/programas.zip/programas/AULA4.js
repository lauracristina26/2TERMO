const entrada = require('readline-sync')

console.log("--- SISTEMA DE ANALISE DE CREDITO ---");

//Coleta de dados
const nome = entrada.question("Nome do cliente: ");
const idade = entrada.question("Idade: ");
const renda = entrada.questionFloat("Renda Mensal: ");
const telemovel = entrada.keyInYNStrict("Possui imovel proprio? "); // Essa função lê Y para true e N para false

// A Lógica Combinada
// (idade >= 18) é obrigatorio
// (renda >== 2500 || telemovel === true) um dos dois tem que ser verdade
if (idade >= 18 && (renda >= 2500 || telemovel === true)) {
    console.log(`\nPARABENS, ${nome}! Seu credito foi APROVADO`);
} else {
    console.log(`\nSinto muito, ${nome}. Seu credito foi NEGADO`); 
}