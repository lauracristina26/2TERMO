const entrada = require('readline-sync');

console.log("--- SISTEMA DE ANALISE DE CREDITO ---");

//Coleta de dados
const nome = entrada.question("Nome do aluno: ");
const n1 = entrada.questionFloat("Nota1: ");
const n2 = entrada.questionFloat("Nota2: ");

const media = (n1 + n2) / 2;

console.log(`\nMedia final de ${nome}: ${media.toFixed(1)}`);

if (media >=7) {
    console.log("APROVADO!");
} else if (media >= 5 && media < 7) {
    console.log("RECUPERACAO")
} else {
    console.log("REPROVADO")
}